public class Request
{
    public string text;
    public Point location;
    public Request(string text, Point location)
    {
        this.text = text;
        this.location = location;
    }
}
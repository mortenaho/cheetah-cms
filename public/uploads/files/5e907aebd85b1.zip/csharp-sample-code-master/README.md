# csharp-sample-code
Basic sample codes for map.ir services

todo list:

- [x] search service
- [x] distance matrix
- [x] reverse geocode
- [x] static map
- [ ] route
- [ ] geofence

package com.mmng.placebook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlacebookApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlacebookApplication.class, args);
	}

}

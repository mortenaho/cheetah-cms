package com.mmng.placebook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlacebookApplicationTests {

	@Test
	void contextLoads() {
	}

}

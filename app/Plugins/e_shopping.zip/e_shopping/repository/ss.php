<?php
/**
 * Created by PhpStorm.
 * User: Mortenaho
 * Date: 7/15/2021
 * Time: 6:45 PM
 */

namespace App\Plugins\e_shopping\repository;


class ss
{

}
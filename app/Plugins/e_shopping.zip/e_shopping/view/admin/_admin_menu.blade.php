<li class="nav-item ">
    <a href="/admin/about_us" class="nav-link {{AdminHelper::active_menu("about_us")}}">
        <i class="icon-info22"></i>
        <span>
                {{trans('admin.about_us')}}
                </span>
    </a>
</li>
<li class="nav-item ">
    <a href="/admin/contact_info" class="nav-link {{AdminHelper::active_menu("contact_info")}}">
        <i class="icon-info3"></i>
        <span>
                {{trans('admin.contact_info')}}
                </span>
    </a>
</li>